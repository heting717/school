package cn.itcast.util;

public class Condition {
	private int typeId;
	//private String sellName;
	public int getTypeId() {
		return typeId;
	}
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
/*	public String getSellName() {
		return sellName;
	}
	public void setSellName(String sellName) {
		this.sellName = sellName;
	}
	@Override
	public String toString() {
		return "Condition [typeId=" + typeId + ", sellName=" + sellName + "]";
	}*/
	
}
