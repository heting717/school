package cn.itcast.entity;

public enum Status {
	
	Free,solve;
}
